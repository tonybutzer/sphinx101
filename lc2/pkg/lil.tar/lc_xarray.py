""" xpart is xarray parts list for creating a common xarray from:

    - an AOI - area of interest
    - an elasticsearch index 

"""

import rasterio
import numpy
import xarray

from .geometry import polygon, CRS, GeoBox
from .lc_geometry import geo_translate, geo_untranslate

class AOI_bounding_box():
    def __init__(self, human_tuple_bb):
        # print(human_tuple_bb)
        h = human_tuple_bb
        print("H:", h)
        self.bounding_box = dict({'left': h[0], 'right': h[2], 'top': h[1], 'bottom': h[3]})
        self.ul_lat = self.bounding_box['top']
        self.ul_lon = self.bounding_box['left']
        self.lr_lat = self.bounding_box['bottom']
        self.lr_lon = self.bounding_box['right']

        top = self.bounding_box['top']
        left = self.bounding_box['left']
        bottom = self.bounding_box['bottom']
        right = self.bounding_box['right']

        points = [ (left,top),
                    (right,top),
                    (right,bottom),
                    (left,bottom),
                    (left,top)
                ]

        input_crs = CRS('EPSG:4326')

        my_gpoly = polygon(points, crs=input_crs)
        # print(my_gpoly)
        #resolution = (-30,30)
        resolution = (30,30)
        output_crs = CRS('epsg:5072')
        # output_crs = CRS('epsg:32636')
        align = None
        my_geobox = GeoBox.from_geopolygon(my_gpoly, resolution, crs=output_crs, align=align)

        # print(my_geobox.shape)

        # print(self.bounding_box)
        # print(my_geobox)
        # print(my_geobox.width)
        # print(my_geobox.height)

        self.geobox = my_geobox
        

class Xpart():
    def __init__(self, geobox, redfile):
        print("thanks for constructing an  Xpart")
        print("redfile is", redfile)
        print(geobox)
        with rasterio.open(redfile) as src:
            print(src.profile)
        self.crs = src.crs
        self.affine = src.transform
        self.width = geobox.width
        self.height = geobox.height

        print(self.width, self.height)

        xs = numpy.arange(self.width) * self.affine.a + (self.affine.c + self.affine.a / 2)
        ys = numpy.arange(self.height) * self.affine.e + (self.affine.f + self.affine.e / 2)

        for x in range(0,9):
            print(xs[x],ys[x])


def NOT_NEEDED_return_aoi_window(ul,lr, file):
    with rasterio.open(file) as src:
        ep = 'epsg:32636'
        ulx,uly = geo_translate(ul[0],ul[1],epsg=ep)
        row1,col1 = src.index(ulx,uly)
        lrx,lry = geo_translate(lr[0],lr[1],epsg=ep)

        row2,col2 = src.index(lrx, lry)
        print(row1,col1)
        print(row2,col2)
        rows = (row1,row2)
        cols = (col1,col2)
        return rows, cols


def read_data_from_geotiff(databuf, index, color, geobox, df):
    geoTiff = df.iloc[index][color]
    # print(geoTiff)
    # Note that the blocksize of the image is 256 by 256, so we want xarray to use some multiple of that
    xchunk = 2048
    ychunk = 2048
    da = xarray.open_rasterio(geoTiff, chunks={'band': 1, 'x': xchunk, 'y': ychunk})
    # print(geobox)
    # print(dir(geobox))
    gextent = geobox.geographic_extent
    # print(dir(gextent))
    bb = gextent.boundingbox
    # print(bb)
    ul = (bb.top, bb.left)
    lr = (bb.bottom, bb.right)
    # ep = 'epsg:32636'
    ep = 'epsg:5072'
    
    
    with rasterio.open(geoTiff) as src:
        # print(src.crs)
        ulx,uly = geo_translate(ul[0],ul[1],epsg=ep)
        row1,col1 = src.index(ulx,uly)
        lrx,lry = geo_translate(lr[0],lr[1],epsg=ep)

        row2,col2 = src.index(lrx, lry)
        #print(row1,col1)
        #print(row2,col2)
        rows = (row1,row2)
        cols = (col1,col2)
        # print(rows, cols)
    
    # print(da)
    my_raster = da.sel(band=1)
   
    # print(my_raster.shape)
    # print(rows[0], rows[1])
    holding_tank = my_raster[rows[0]:rows[1], cols[0]:cols[1]]
    numpy.copyto(databuf,holding_tank)
    



def build_the_xarray(geobox, measures, df):
    data = {}
    THE_XARRAY = xarray.Dataset(attrs={'crs': geobox.crs})
    
    # print(THE_XARRAY)
    time_coords = []
    date_coords = []
    for idx, val in df.iterrows():
        key = val['date'] + '_' + val['path'] + '_' + val['row']
        # print (key)
        time_coords.append(key)
        date_coords.append(val['date'])
    
    THE_XARRAY['datePR'] = time_coords
    THE_XARRAY['time'] = date_coords
    # print(THE_XARRAY)
    
    #print(geobox.coordinates.items())
    
    for name, coord in geobox.coordinates.items():
            THE_XARRAY[name] = (name, coord.values, {'units': coord.units})
            # print("GN=",name)
            # print(name, len(coord.values))
            # print(name, coord.values[0])
    # print(THE_XARRAY)
    
    print ("TON letime_coords", len(time_coords))
    # sys.exit(0)
    datePR_shape = (len(time_coords), )
    
    for color in measures:
        data[color] = numpy.full(datePR_shape + geobox.shape, '-9999', dtype='int16')

        # print("color data.shape", color, data[color].shape)
    
        attrs = {
                    'nodata': '-9999',
                    'units': 'metres',
                    'crs': geobox.crs
                }

    #dims = 'datePR' + tuple(geobox.dimensions)
    
        dims = ('datePR', 'y', 'x')
    
        THE_XARRAY[color] = (dims, data[color], attrs)
        # we NOW have an EMPTY XARRAY
        # print(THE_XARRAY)
    
        for index in range(0,len(time_coords)):
            print("INDEX=",index,color)
            read_data_from_geotiff(data[color][index], index, color, geobox, df)
    
        # print(THE_XARRAY)
        
        
    return THE_XARRAY

